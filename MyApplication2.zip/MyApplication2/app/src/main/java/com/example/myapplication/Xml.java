package com.example.myapplication;

//https://www.tutorialspoint.com/android/android_xml_parsers.htm

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;

public class Xml {

    public Observable<ArrayList<String>> getObservableXml()
    {
        return Observable.create(new ObservableOnSubscribe<ArrayList<String>>() {
            @Override
            public void subscribe(ObservableEmitter<ArrayList<String>> emitter) throws Exception {
                ArrayList<String> list=getXML();
                if (list!=null && !emitter.isDisposed())
                {
                    emitter.onNext(list);
                    emitter.onComplete();
                }
                else
                {
                    emitter.onError(new Exception());
                }
            }
        });
    }


    public static  ArrayList<String> getXML() {


        try {
            ArrayList<String> urls = new ArrayList<>();

            InputStream input = new URL("http://192.168.10.106/channels/channel.xml").openStream();

            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.parse(input);

            Element element = doc.getDocumentElement();
            element.normalize();

            NodeList nList = doc.getElementsByTagName("channel");

            int size = nList.getLength();

            for (int i = 0; i < nList.getLength(); i++) {
                Node node = nList.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element1 = (Element) node;
                    String url = getValue("url", element1);
                    urls.add(url);
                    System.out.println(url + "majid");
                }
            }
            return urls;
        }
        catch (Exception e)
        {
            e.getMessage();
            return null;
        }
    }

    private static String getValue(String tag,Element element)
    {
        NodeList nodeList=element.getElementsByTagName(tag).item(0).getChildNodes();
        Node node=nodeList.item(0);
        return node.getNodeValue();
    }
}
